.. _example_check_data:

Check Dataset Files
===================

You can check if there is any missing file in the dataset by the following code.

.. literalinclude:: ../../examples/exam_check_data.py